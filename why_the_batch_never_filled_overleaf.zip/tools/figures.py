#!/usr/bin/env python3
"""Report figures — generated from agg.json + the repo's summary CSVs.

Design system: dataviz reference palette (light mode), categorical slots in
fixed order (cam0..cam3 = slots 1..4), sequential blue for magnitude, status
red only for genuine failure states, thin marks, solid hairline grid,
selective direct labels, one axis per plot.
"""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap

HERE = os.path.dirname(os.path.abspath(__file__))
FIGDIR = os.path.join(HERE, "report", "figures")
AGG = json.load(open(os.path.join(HERE, "agg.json")))

SURFACE = "#ffffff"
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#898781"
GRID, BASE = "#e1e0d9", "#c3c2b7"
CAMS = ["#2a78d6", "#1baf7a", "#eda100", "#008300"]
S1, S2, S3 = "#2a78d6", "#1baf7a", "#eda100"
CRIT = "#d03b3b"
RAMP4 = ["#86b6ef", "#5598e7", "#2a78d6", "#184f95"]
SEQ = LinearSegmentedColormap.from_list(
    "seqblue", ["#cde2fb", "#9ec5f4", "#5598e7", "#2a78d6", "#1c5cab", "#0d366b"])

plt.rcParams.update({
    "font.family": "sans-serif", "font.size": 8.5,
    "axes.titlesize": 9.5, "axes.labelsize": 8.5,
    "figure.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
})

def style(ax, grid_axis="both"):
    ax.grid(True, axis=grid_axis, color=GRID, linewidth=0.8, linestyle="-")
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(BASE)
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.xaxis.label.set_color(INK2)
    ax.yaxis.label.set_color(INK2)
    ax.title.set_color(INK)

def logticks(ax, ticks, labels=None):
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels or [f"{t:g}" for t in ticks])
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())

def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIGDIR, f"{name}.{ext}"), dpi=150,
                    bbox_inches="tight")
    plt.close(fig)
    print("saved", name)

# =============================================================================
# 1. fig_pipeline
# =============================================================================
def fig_pipeline():
    fig, ax = plt.subplots(figsize=(6.9, 3.3))
    ax.set_xlim(0, 100); ax.set_ylim(0, 42); ax.axis("off")

    def box(x, y, w, h, text, fc="#f9f9f7", ec=BASE, tc=INK, fs=6.6, bold=False):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25",
                                    fc=fc, ec=ec, lw=0.9))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
                fontsize=fs, color=tc, fontweight="bold" if bold else "normal")

    def arrow(x0, y0, x1, y1, color=BASE):
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
                                     mutation_scale=7, color=color, lw=0.9))

    chain = [("v4l2src", 8.6), ("jpegparse", 10.2), ("nvjpegdec", 10.2),
             ("nvvideoconvert", 14.4)]
    ys = [30, 23, 16, 9]
    for c, y in enumerate(ys):
        ax.add_patch(plt.Rectangle((0.8, y + 1.0), 2.0, 2.0, fc=CAMS[c], ec="none"))
        ax.text(1.8, y - 0.8, f"C920 #{c}", ha="center", fontsize=5.8, color=INK2)
        x = 4.4
        for name, w in chain:
            box(x, y, w, 4, name)
            if x > 4.4:
                arrow(x - 0.85, y + 2, x + 0.05, y + 2)
            x += w + 0.9
        arrow(x - 0.85, y + 2, 54.3, {0: 25.8, 1: 23.0, 2: 20.0, 3: 17.2}[c])

    # jpegparse warning above the top row
    jx = 4.4 + 8.6 + 0.9 + 10.2 / 2
    ax.plot([jx, jx], [34.4, 36.6], color=CRIT, lw=0.8)
    ax.text(jx, 37.2,
            "PTS re-stamped here: ideal 33.33 ms grid,\nanchored at this camera's own start instant",
            ha="center", va="bottom", fontsize=6.4, color=CRIT)
    ax.text(26, 4.6,
            "small NVMM buffer pools per element " + r"($\approx$4 buffers $\approx$ 130 ms of video @ 30 fps)",
            ha="center", fontsize=6.3, color=MUTED, style="italic")

    box(54.5, 15.5, 11.5, 12, "nvstreammux\nbatch = 4\n\nlegacy: Python\nnew: C++",
        fc="#eef4fc", ec=S1, bold=True, fs=6.3)
    ax.text(99.5, 1.6, "mux knobs: sync-inputs " + r"$\cdot$" + " max-latency " +
            r"$\cdot$" + " batched-push-timeout", ha="right", fontsize=6.3,
            color=INK2)
    arrow(66.3, 21.5, 68.0, 21.5)
    box(68.2, 18, 9.6, 7, "nvinfer\nYOLO11n")
    arrow(78.1, 21.5, 79.8, 21.5)
    box(80.0, 18, 9.6, 7, "nvtracker\nNvSORT")
    arrow(89.9, 21.5, 91.6, 21.5)
    box(91.8, 18, 8.0, 7, "JSON out\nper cam,\nper frame", fs=6.2)
    ax.text(73.0, 16.4, "one inference pass\nper batch", ha="center", va="top",
            fontsize=6.0, color=MUTED)
    save(fig, "fig_pipeline")

# =============================================================================
# 2. fig_two_clocks (baseline_pinned)
# =============================================================================
def fig_two_clocks():
    r = AGG["frame_timing"]["baseline_pinned"]
    true_ms = {int(c): np.array(v) for c, v in r["raster_true_ms"].items()}
    syn_s = {int(c): np.array(v) for c, v in r["raster_syn_s"].items()}
    lag = {c: np.median(syn_s[c] * 1000 - true_ms[c]) for c in true_ms}
    off = {c: lag[c] - lag[0] for c in true_ms}

    fig, (a, b) = plt.subplots(2, 1, figsize=(6.6, 3.6))
    for c in range(4):
        a.plot(true_ms[c] / 1000, np.full_like(true_ms[c], 3 - c), "|",
               ms=9, mew=1.4, color=CAMS[c])
        b.plot(syn_s[c], np.full_like(syn_s[c], 3 - c), "|",
               ms=9, mew=1.4, color=CAMS[c])
        for ax in (a, b):
            ax.text(-0.012, 3 - c, f"cam {c}", transform=ax.get_yaxis_transform(),
                    ha="right", va="center", fontsize=7.5, color=INK2)
        b.text(1.005, 3 - c,
               "offset 0 (ref)" if c == 0 else f"{off[c]:+,.0f} ms",
               transform=b.get_yaxis_transform(), ha="left", va="center",
               fontsize=7.0, color=INK2)
    a.set_title("the same one second of video, on the two clocks", loc="left", pad=10)
    a.text(0.995, 1.03, "real: interleaved within one frame period",
           transform=a.transAxes, ha="right", va="bottom", fontsize=7.4, color=MUTED)
    b.set_title("synthetic: four grids spanning ~1.1 s", loc="right",
                fontsize=7.4, color=MUTED, pad=4)
    a.set_xlabel("true capture time (kernel stamp), seconds within the window")
    b.set_xlabel("presentation timestamp (PTS) the same frames carry after jpegparse, s")
    a.set_xlim(0, 1.0)
    for ax in (a, b):
        ax.set_ylim(-0.7, 3.7); ax.set_yticks([])
        style(ax, grid_axis="x")
    fig.tight_layout(h_pad=1.8)
    save(fig, "fig_two_clocks")

# =============================================================================
# 3. fig_spread_cdf (baseline_pinned)
# =============================================================================
def fig_spread_cdf():
    r = AGG["frame_timing"]["baseline_pinned"]["cdf"]
    q = np.linspace(0, 100, 400)
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    ax.axvspan(39, 46, color=GRID, alpha=0.55, lw=0)
    ax.text(42.5, 5, "RT-BEV,\nhw-synced\nnuScenes:\n39–46 ms", ha="center",
            va="bottom", fontsize=6.4, color=MUTED)
    series = [("nearest-frame sets (physics)", r["nearest"], S1),
              ("as batched by nvstreammux (true capture)", r["batch_true"], S2),
              ("as batched, on synthetic PTS (what the mux believes)", r["batch_syn"], S3)]
    for name, cdf, col in series:
        ax.plot(cdf, q, color=col, lw=2, solid_capstyle="round", label=name)
    ax.text(8.3, 62, "p50 8.9 ms", fontsize=7.2, color=INK2, ha="right")
    ax.text(200, 40, "p50 209 ms", fontsize=7.2, color=INK2, ha="right")
    ax.text(1000, 55, "constant\n1050 ms", fontsize=7.2, color=INK2, ha="right")
    ax.set_xscale("log")
    ax.set_xlim(1.5, 2600); ax.set_ylim(0, 104)
    logticks(ax, [2, 5, 10, 33, 100, 209, 500, 1050, 2000])
    ax.set_xlabel("max time difference among the 4 cameras' frames in one sample set (ms, log)")
    ax.set_ylabel("percentile")
    ax.set_title("three definitions of cross-camera skew — 120 s baseline run, sync off",
                 loc="left", pad=8)
    ax.legend(fontsize=6.8, frameon=False, loc="upper left", handlelength=1.6)
    style(ax)
    save(fig, "fig_spread_cdf")

# =============================================================================
# 4. fig_staleness (baseline_pinned)
# =============================================================================
def fig_staleness():
    r = AGG["frame_timing"]["baseline_pinned"]
    q = np.linspace(0, 100, 400)
    p50 = {int(c): v["p50"] for c, v in r["staleness_ms_per_cam"].items()}
    start = r["first_capture_s"]
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    lab_xy = {0: (258, 70), 1: (185, 55), 2: (45, 47), 3: (150, 25)}
    for c in range(4):
        cdf = r["cdf"]["stale"][str(c)]
        ax.plot(cdf, q, color=CAMS[c], lw=2, solid_capstyle="round",
                label=f"cam {c} (started t+{start[str(c)]:.1f} s)")
        ax.annotate(f"cam {c}: p50 {p50[c]:.0f} ms", (p50[c], 50),
                    xytext=lab_xy[c], fontsize=7.0, color=INK2,
                    arrowprops=dict(arrowstyle="-", color=BASE, lw=0.7))
    ax.set_xlim(0, 400); ax.set_ylim(0, 100)
    ax.set_xlabel("age of the camera's pixels when its batch leaves the mux (ms)")
    ax.set_ylabel("percentile")
    ax.set_title("standing-queue skew: earlier-started cameras are served stale, forever",
                 loc="left", pad=8)
    ax.legend(fontsize=7.0, frameon=False, loc="lower right")
    style(ax)
    save(fig, "fig_staleness")

# =============================================================================
# 5. fig_sync_off (control experiment)
# =============================================================================
def fig_sync_off():
    st = AGG["timeout_sweep_static"]
    dy = AGG["timeout_sweep_dynamic"]
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.6, 2.9))
    for rows, col, lab in ((st, S1, "static batch-4 engine"),
                           (dy, S2, "dynamic-batch engine")):
        ms = [float(r["push_ms"]) for r in rows]
        a.plot(ms, [float(r["mean_n_in_batch"]) for r in rows], "o-", color=col,
               lw=2, ms=4.5, label=lab)
        b.plot(ms, [float(r["e2e_mean_ms"]) for r in rows], "o-", color=col,
               lw=2, ms=4.5, label=lab)
    for ax in (a, b):
        ax.set_xscale("log")
        logticks(ax, [1, 5, 10, 33.3, 100])
        ax.axvline(33.3, color=GRID, lw=0.9)
        ax.set_xlabel("batched-push-timeout (ms, log)")
        style(ax)
    a.axhline(4, color=BASE, lw=0.9)
    a.text(1.1, 4.06, "full batch (4)", fontsize=6.8, color=MUTED, va="bottom")
    a.set_ylim(0.8, 4.4)
    a.set_ylabel("mean frames per batch")
    a.set_title("fills to ~4 within one frame period", loc="left")
    b.set_ylim(0, 200)
    b.set_ylabel("end-to-end latency, mean (ms)")
    b.set_title("the cost of waiting longer", loc="left")
    a.legend(fontsize=6.8, frameon=False, loc="lower right")
    fig.suptitle("sync-inputs OFF: the same 4 cameras batch fine — capture is not the problem",
                 x=0.01, ha="left", fontsize=9.5, color=INK, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    save(fig, "fig_sync_off")

# =============================================================================
# 6. fig_sweep_floor
# =============================================================================
def fig_sweep_floor():
    sw = AGG["sync_sweep"]
    fig, ax = plt.subplots(figsize=(6.6, 3.4))
    ax.axvspan(1050, 1468, color=GRID, alpha=0.8, lw=0)
    ax.text(1240, 3.62, "required window:\nmeasured synthetic-PTS\noffsets, 1.05–1.47 s",
            ha="center", fontsize=7.0, color=INK2)
    ax.axhline(4, color=BASE, lw=0.9)
    ax.text(14, 4.05, "full batch (4 cameras)", fontsize=6.8, color=MUTED, va="bottom")

    for key, col, mk, lab in (("push_33ms", S1, "o", "sync_sweep, push = 33 ms"),
                              ("push_match", S2, "s", "sync_sweep, push = max-latency")):
        pts = sorted(((float(m), s["mean_nin"]) for m, s in sw[key].items()),
                     key=lambda p: p[0])
        ax.plot([p[0] for p in pts], [p[1] for p in pts], mk + "-", color=col,
                lw=2, ms=4.5, label=lab)
    best = {}
    for key, s in AGG["sync_grid"].items():
        ml = float(key.split("_")[0])
        if not s.get("dead"):
            best[ml] = max(best.get(ml, 0), s["mean_nin"])
    mls = sorted(best)
    ax.plot(mls, [best[m] for m in mls], "D-", color=S3, lw=2, ms=4.5,
            label="sync_grid, best cell per max-latency")
    for ml, y in ((350, 1.0), (500, 0.98)):
        ax.plot([ml], [y], "x", color=CRIT, ms=8, mew=2.2)
    ax.annotate("pipeline froze: 0 batches recorded\n(ml=500: all 5 runs; ml=350 with push=500)",
                (500, 0.98), xytext=(120, 0.60), fontsize=7.0, color=CRIT,
                arrowprops=dict(arrowstyle="-", color=CRIT, lw=0.7))
    ax.annotate("", xy=(1050, 2.65), xytext=(210, 2.65),
                arrowprops=dict(arrowstyle="->", color=INK2, lw=1.0))
    ax.text(460, 2.73, "every value ever tested\nsits below the floor", ha="center",
            fontsize=7.2, color=INK2)
    ax.set_xscale("log")
    ax.set_xlim(13, 2400); ax.set_ylim(0.45, 4.4)
    logticks(ax, [16, 33, 66, 100, 200, 350, 500, 1050, 2000])
    ax.set_xlabel("nvstreammux max-latency (ms, log) — sync-inputs = 1, legacy mux, live cameras")
    ax.set_ylabel("mean frames per batch (of 4)")
    ax.set_title("the sweeps could not have found a working point: "
                 "0% full batches in every run, at every setting", loc="left", pad=8)
    ax.legend(fontsize=7.0, frameon=False, loc="center left")
    style(ax)
    save(fig, "fig_sweep_floor")

# =============================================================================
# 7. fig_grid_heat
# =============================================================================
def fig_grid_heat():
    mls = [50, 100, 200, 350, 500]
    pushes = [50, 100, 200, 350, 500]
    M = np.full((5, 5), np.nan)
    for key, s in AGG["sync_grid"].items():
        ml, pu = (float(x) for x in key.split("_"))
        if not s.get("dead"):
            M[mls.index(ml), pushes.index(pu)] = s["mean_nin"]
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    im = ax.imshow(M, origin="lower", cmap=SEQ, vmin=1, vmax=4, aspect="auto")
    for k in range(6):
        ax.axhline(k - 0.5, color=SURFACE, lw=2)
        ax.axvline(k - 0.5, color=SURFACE, lw=2)
    for i in range(5):
        for j in range(5):
            if np.isnan(M[i, j]):
                ax.text(j, i, "froze\n0 batches", ha="center", va="center",
                        fontsize=7.0, color=CRIT, fontweight="bold")
            else:
                ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center",
                        fontsize=7.6, color=INK)
    ax.set_xticks(range(5)); ax.set_xticklabels([f"{p:g}" for p in pushes])
    ax.set_yticks(range(5)); ax.set_yticklabels([f"{m:g}" for m in mls])
    ax.set_xlabel("batched-push-timeout (ms)")
    ax.set_ylabel("max-latency (ms)")
    ax.set_title("sync_grid: mean frames per batch (of 4) — 16 s live runs",
                 loc="left", pad=8)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
    cb.set_label("mean frames per batch", fontsize=7.6, color=INK2)
    cb.ax.tick_params(labelsize=7, colors=MUTED)
    cb.outline.set_edgecolor(BASE)
    ax.tick_params(colors=MUTED)
    ax.xaxis.label.set_color(INK2); ax.yaxis.label.set_color(INK2)
    ax.title.set_color(INK)
    save(fig, "fig_grid_heat")

# =============================================================================
# 8. fig_ceiling
# =============================================================================
def fig_ceiling():
    fig, ax = plt.subplots(figsize=(6.6, 2.8))
    rows = [   # top -> bottom
        ("required window\n(measured grid offsets)", 1050, 1468, "#104281"),
        ("measured survival boundary\n(sync_grid, legacy app)", 20, 350, "#5598e7"),
        ("per-branch NVMM pool\n" + r"$\approx$4 buffers @ 30 fps", 20, 133, "#9ec5f4"),
        ("one frame period", 20, 33.3, "#cde2fb"),
    ]
    for i, (lab, x0, x1, col) in enumerate(rows):
        y = len(rows) - 1 - i
        ax.barh(y, x1 - x0, left=x0, height=0.52, color=col)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([r[0] for r in rows][::-1], fontsize=7.2, color=INK2)
    ax.text(1500, 3, " 1050–1468 ms", va="center", fontsize=7.2, color=INK2)
    ax.text(310, 2, "alive " + r"$\leq$" + " 350 ms ", va="center", ha="right",
            fontsize=7.0, color=INK)
    ax.plot([500], [2], "x", color=CRIT, ms=9, mew=2.4)
    ax.text(545, 2, "froze at 500 ms", va="center", fontsize=7.2, color=CRIT)
    ax.text(137, 1, " 133 ms", va="center", fontsize=7.2, color=INK2)
    ax.text(34.5, 0, " 33.3 ms", va="center", fontsize=7.2, color=INK2)
    ax.annotate("", xy=(1050, 2.52), xytext=(350, 2.52),
                arrowprops=dict(arrowstyle="<->", color=INK, lw=1.1))
    ax.text(608, 2.62, "gap: " + r"$3\times$" + " past the freeze point, "
            r"$8$–$11\times$" + " past the pool budget", ha="center",
            fontsize=7.2, color=INK)
    ax.set_xscale("log")
    ax.set_xlim(20, 5000)
    logticks(ax, [33, 133, 350, 500, 1050, 1468, 3000])
    ax.set_ylim(-0.55, 3.75)
    ax.set_xlabel("hold time the setting implies / window width (ms, log)")
    ax.set_title("the requirement exceeds what the legacy pipeline can hold",
                 loc="left", pad=8)
    style(ax, grid_axis="x")
    ax.tick_params(axis="y", length=0)
    save(fig, "fig_ceiling")

# =============================================================================
# 9. fig_spiral
# =============================================================================
def fig_spiral():
    fig, ax = plt.subplots(figsize=(6.3, 3.5))
    ax.set_xlim(0, 100); ax.set_ylim(0, 60); ax.axis("off")
    nodes = [
        (50, 52, "mux HOLDS buffers\n(sync alignment / wide window)", "#eef4fc", S1, INK),
        (81, 30, "per-branch NVMM pools drain\n(only ~4 buffers exist)", "#f9f9f7", BASE, INK),
        (50, 8, "v4l2src cannot dequeue:\ncapture STALLS (v4l2 error -5)", "#fdf0f0", CRIT, CRIT),
        (19, 30, "fewer frames reach the mux;\nbatches stay incomplete", "#f9f9f7", BASE, INK),
    ]
    for x, y, t, fc, ec, tc in nodes:
        ax.add_patch(FancyBboxPatch((x - 17, y - 5.5), 34, 11,
                                    boxstyle="round,pad=0.4", fc=fc, ec=ec, lw=1.1))
        ax.text(x, y, t, ha="center", va="center", fontsize=7.3, color=tc)
    arrows = [((68, 46.5), (79, 37.5)), ((79, 22.5), (68, 13.5)),
              ((32, 13.5), (21, 22.5)), ((21, 37.5), (32, 46.5))]
    for (x0, y0), (x1, y1) in arrows:
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
                                     mutation_scale=11, color=INK2, lw=1.3,
                                     connectionstyle="arc3,rad=-0.25"))
    ax.text(50, 30, "the mux waits even longer\nfor the missing cameras\n" +
            r"$\circlearrowleft$", ha="center", va="center", fontsize=7.6, color=INK2)
    ax.set_title("why “just set the window really big” kills the legacy pipeline",
                 loc="left", color=INK, pad=10)
    save(fig, "fig_spiral")

# =============================================================================
# 10. fig_sync_survivors (sync_pinned)
# =============================================================================
def fig_sync_survivors():
    r = AGG["frame_timing"]["sync_pinned"]
    arr = {int(c): v for c, v in r["arrivals_per_cam_ss"].items()}
    sur = {int(c): v for c, v in r["survivors_per_cam_ss"].items()}
    off = {0: 0.0, 1: -566.5, 2: -1365.0, 3: -1.1}
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.6, 2.9),
                               gridspec_kw={"width_ratios": [1.25, 1]})
    for c in range(4):
        y = 3 - c
        a.barh(y, arr[c], height=0.55, color=CAMS[c], alpha=0.22)
        a.barh(y, sur[c], height=0.55, color=CAMS[c])
        a.text(arr[c] + 60, y,
               f"{sur[c]:,} of {arr[c]:,} ({100 * sur[c] / arr[c]:.0f}%)   "
               f"grid {off[c]:+,.0f} ms",
               va="center", fontsize=7.0, color=INK2)
        a.text(-120, y, f"cam {c}", ha="right", va="center", fontsize=7.6, color=INK2)
    a.set_xlim(0, 8600); a.set_yticks([])
    a.set_xticks([0, 1750, 3500])
    a.set_xlabel("frames in 117 s steady state (filled = batched, pale = arrived)")
    a.set_title("who survives is decided by grid luck", loc="left")
    style(a, grid_axis="x")

    sizes = {int(k): v for k, v in r["batch_size_hist_ss"].items()}
    for k in range(1, 5):
        b.bar(k, sizes.get(k, 0), width=0.62, color=RAMP4[k - 1])
        b.text(k, sizes.get(k, 0) + 7, f"{sizes.get(k, 0)}", ha="center",
               fontsize=7.4, color=INK2)
    b.annotate("255 of 388 batches are exactly\nthe pair {cam 0, cam 3} —\nthe two grids 1.1 ms apart",
               (2, 258), xytext=(2.45, 285), fontsize=6.8, color=INK2,
               arrowprops=dict(arrowstyle="-", color=BASE, lw=0.7))
    b.set_xticks([1, 2, 3, 4])
    b.set_xlabel("frames in batch")
    b.set_ylabel("batches")
    b.set_ylim(0, 372)
    b.set_title("15.7% full; cadence 32.5" + r"$\,\rightarrow\,$" + "201 ms", loc="left")
    style(b, grid_axis="y")
    fig.suptitle("new mux, sync-inputs=1, max-latency=33 ms: 93.6% of frames silently erased",
                 x=0.01, ha="left", fontsize=9.5, color=INK, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    save(fig, "fig_sync_survivors")

# =============================================================================
# 11. fig_windows
# =============================================================================
def fig_windows():
    fig, axes = plt.subplots(2, 1, figsize=(6.8, 4.0), sharex=True)
    offs = [566, 1365]

    def lane(ax, early_end, late_end, title, note, note_col, compact):
        ax.axvspan(10, early_end, color="#cde2fb")
        ax.axvspan(early_end, late_end, color="#1baf7a", alpha=0.18)
        ax.axvspan(late_end, 60000, color=CRIT, alpha=0.10)
        if not compact:
            ax.text(np.sqrt(10 * early_end), 0.70, "EARLY:\nheld in queue",
                    ha="center", fontsize=6.8, color="#104281")
            ax.text(np.sqrt(early_end * late_end), 0.70,
                    "eligible for a batch on arrival\n(retention by classification — nothing waits)",
                    ha="center", fontsize=6.8, color="#00694a")
            ax.text(np.sqrt(late_end * 60000), 0.70, "LATE:\nerased",
                    ha="center", fontsize=6.8, color=CRIT)
            ax.text(offs[0], 0.10,
                    "the frames that must survive: measured grid offsets 566 / 1365 ms",
                    ha="center", fontsize=6.6, color=INK)
        else:
            ax.text(np.sqrt(10 * early_end), 0.70,
                    "EARLY: every frame HELD until it is 10 s old",
                    ha="center", fontsize=6.8, color="#104281")
            ax.text(np.sqrt(early_end * late_end), 0.42, "eligible",
                    ha="center", fontsize=6.4, color="#00694a", rotation=90)
            ax.text(np.sqrt(late_end * 60000), 0.42, "LATE", ha="center",
                    fontsize=6.4, color=CRIT, rotation=90)
        for o in offs:
            ax.plot([o], [0.28], "o", color=INK, ms=5)
        ax.axvline(133, color=MUTED, lw=0.9)
        ax.set_ylim(0, 1); ax.set_yticks([])
        ax.set_title(title, loc="left", fontsize=8.0, color=INK, pad=14)
        ax.text(1.0, 1.04, note, transform=ax.transAxes, ha="right",
                fontsize=7.0, color=note_col)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.spines["bottom"].set_color(BASE)
        ax.tick_params(colors=MUTED, labelsize=7.5)

    lane(axes[0], 33.3, 33.3 + 2000,
         "workable:  --sync --max-latency-ms 2000 --timeout-us 33333",
         "max hold = 33 ms " + r"$\ll$" + " pool budget " + r"$\checkmark$",
         "#00694a", compact=False)
    lane(axes[1], 10000, 20000,
         "the trap: “set both to 10 s” — push-timeout silently overwrites the EARLY gate",
         "hold = 10 s " + r"$\approx$" + " 300 buffers/cam vs pool of 4 " +
         r"$\Rightarrow$" + " stalls", CRIT, compact=True)
    axes[0].text(133, 1.04, "pool budget " + r"$\approx$" + "133 ms", ha="center",
                 fontsize=6.4, color=MUTED)
    axes[1].set_xscale("log")
    axes[1].set_xlim(10, 60000)
    logticks(axes[1], [10, 33, 133, 566, 1365, 2033, 10000, 20000],
             ["10", "33", "133", "566", "1365", "2033", "10k", "20k"])
    axes[1].set_xlabel("frame age when the mux classifies it (ms, log) — "
                       "eligible while age " + r"$\in$" + " [EARLY gate, EARLY gate + max-latency + upstream]")
    fig.suptitle("the two knobs act on opposite edges of the window: widen the late edge (free), "
                 "never push the early edge out", x=0.01, ha="left",
                 fontsize=9.3, color=INK, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.93], h_pad=2.4)
    save(fig, "fig_windows")

for f in (fig_pipeline, fig_two_clocks, fig_spread_cdf, fig_staleness,
          fig_sync_off, fig_sweep_floor, fig_grid_heat, fig_ceiling,
          fig_spiral, fig_sync_survivors, fig_windows):
    f()
print("all figures done ->", FIGDIR)
