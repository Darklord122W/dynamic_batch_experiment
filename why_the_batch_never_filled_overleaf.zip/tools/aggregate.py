#!/usr/bin/env python3
"""Aggregate every experiment CSV in the repo into one JSON for the report figures."""
import csv, json, os, re, statistics as st
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

ROOT = "/home/darklord01/Documents/deepstream_batch/multicam_perception_rt"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agg.json")
WARMUP = 4.0

def load_metrics(path, warmup=WARMUP):
    if not os.path.exists(path):
        return None
    with open(path) as f:
        rows = [r for r in csv.DictReader(f) if float(r["t_mono"]) >= warmup]
    return rows or None

def summarize(rows, num_cams=4):
    nin = [int(r["n_in_batch"]) for r in rows]
    t = [float(r["t_mono"]) for r in rows]
    dur = max(t[-1] - t[0], 1e-6)
    e2e = sorted(float(r["e2e_ms"]) for r in rows if float(r["e2e_ms"]) >= 0)
    dist = Counter(nin)
    return {
        "n_batches": len(nin),
        "duration_s": round(dur, 2),
        "mean_nin": round(st.mean(nin), 3),
        "pct_full": round(100.0 * dist.get(num_cams, 0) / len(nin), 2),
        "batches_s": round(len(nin) / dur, 2),
        "in_time_fps": round(sum(nin) / dur, 2),
        "e2e_mean": round(st.mean(e2e), 1) if e2e else None,
        "e2e_p99": round(e2e[int(0.99 * (len(e2e) - 1))], 1) if e2e else None,
        "dist": {str(k): dist.get(k, 0) for k in range(num_cams + 1)},
    }

agg = {}

# ---------------- sync_sweep (1D max-latency sweep, sync ON) ----------------
sweep = {"push_33ms": {}, "push_match": {}}
d = os.path.join(ROOT, "experiments/results/sync_sweep")
for fn in sorted(os.listdir(d)):
    m = re.match(r"(push_33ms|push_match)_ml([\d.]+)\.csv", fn)
    if not m:
        continue
    rows = load_metrics(os.path.join(d, fn))
    sweep[m.group(1)][float(m.group(2))] = summarize(rows) if rows else {"n_batches": 0, "dead": True}
agg["sync_sweep"] = sweep

# ---------------- sync_grid (2D max-latency x push, sync ON) ----------------
grid = {}
d = os.path.join(ROOT, "experiments/results/sync_grid")
for fn in sorted(os.listdir(d)):
    m = re.match(r"ml([\d.]+)_push([\d.]+)\.csv", fn)
    if not m:
        continue
    rows = load_metrics(os.path.join(d, fn))
    key = f"{float(m.group(1)):g}_{float(m.group(2)):g}"
    grid[key] = summarize(rows) if rows else {"n_batches": 0, "dead": True}
agg["sync_grid"] = grid

# ---------------- timeout sweeps (sync OFF) — copy summary CSVs -------------
for name, sub in [("timeout_sweep_static", "timeout_sweep"),
                  ("timeout_sweep_dynamic", "timeout_sweep_dynamic")]:
    p = os.path.join(ROOT, "experiments/results", sub, "summary.csv")
    with open(p) as f:
        agg[name] = list(csv.DictReader(f))

# ---------------- frame_timing runs ------------------------------------------
FT = os.path.join(ROOT, "cpp/experiments/frame_timing/results")

def ft_load(run):
    cap = pd.read_csv(os.path.join(FT, run, "capture.csv"))
    pre = pd.read_csv(os.path.join(FT, run, "premux.csv"))
    bat = pd.read_csv(os.path.join(FT, run, "batches.csv"))
    bf = pd.read_csv(os.path.join(FT, run, "batch_frames.csv"))
    meta = json.load(open(os.path.join(FT, run, "meta.json")))
    return cap, pre, bat, bf, meta

def steady_window(cap):
    t0 = cap.mono_ns.min() + int(2.0e9)
    t1 = cap.mono_ns.max() - int(0.5e9)
    return t0, t1

ft = {}
for run in ["baseline", "baseline_pinned", "sync_pinned"]:
    cap, pre, bat, bf, meta = ft_load(run)
    bt_ns = meta["base_time_ns"]
    cap["cap_ns"] = cap.pts_ns + bt_ns   # kernel capture stamp on the monotonic clock
    t0, t1 = steady_window(cap)
    r = {"meta": {k: meta[k] for k in ("sync_inputs", "max_latency_ns", "batched_push_timeout_us", "duration_s")}}

    # (1) per-camera PTS anchor: mono_ns - pts_ns should be ~constant per camera
    anchors = {}
    for c in sorted(pre.cam.unique()):
        sel = pre[pre.cam == c]
        anchors[int(c)] = float(np.median(sel.mono_ns - sel.pts_ns))
    a0 = anchors[min(anchors)]
    r["pts_anchor_offset_ms_vs_cam0"] = {c: round((a0 - a) / 1e6, 1) for c, a in anchors.items()}
    # synthetic-PTS offset between cameras at the SAME instant = anchor difference
    r["synthetic_offset_span_ms"] = round((max(anchors.values()) - min(anchors.values())) / 1e6, 1)

    # (2) startup stagger: first capture + first premux arrival per camera (s after run start)
    run_start = cap.mono_ns.min()
    r["first_capture_s"] = {int(c): round(float(cap[cap.cam == c].mono_ns.min() - run_start) / 1e9, 3)
                            for c in sorted(cap.cam.unique())}

    # (3) steady-state arrivals vs departures (the discard rate)
    pre_ss = pre[(pre.mono_ns >= t0) & (pre.mono_ns <= t1)]
    bat_ss = bat[(bat.mono_ns >= t0) & (bat.mono_ns <= t1)]
    bf_ss = bf[bf.batch_idx.isin(bat_ss.batch_idx)]
    r["arrivals_ss"] = int(len(pre_ss))
    r["frames_out_ss"] = int(len(bf_ss))
    r["discard_pct"] = round(100.0 * (1 - len(bf_ss) / max(len(pre_ss), 1)), 1)
    r["batches_ss"] = int(len(bat_ss))
    r["arrivals_per_cam_ss"] = {int(c): int(n) for c, n in pre_ss.cam.value_counts().sort_index().items()}
    r["survivors_per_cam_ss"] = {int(c): int(n) for c, n in bf_ss.source_id.value_counts().sort_index().items()}
    sizes = Counter(bf_ss.groupby("batch_idx").size())
    r["batch_size_hist_ss"] = {str(k): int(v) for k, v in sorted(sizes.items())}
    r["pct_full_ss"] = round(100.0 * sizes.get(4, 0) / max(sum(sizes.values()), 1), 1)
    cad = np.diff(np.sort(bat_ss.mono_ns.values)) / 1e6
    r["batch_cadence_median_ms"] = round(float(np.median(cad)), 1) if len(cad) else None

    # batch composition (which camera sets co-occur)
    comp = Counter(tuple(sorted(g.source_id.tolist())) for _, g in bf_ss.groupby("batch_idx"))
    r["top_compositions_ss"] = [["+".join(map(str, k)), int(v)] for k, v in comp.most_common(6)]

    # (4) true-capture spread inside each batch + staleness, via P1<->P2 exact-PTS
    #     match and P0<->P1 per-camera FIFO match.
    true_cap = {}   # (cam, premux_pts) -> kernel capture instant (monotonic ns)
    pair = {}       # cam -> (capture instants, matched synthetic premux pts)
    fifo_ok = True
    for c in sorted(cap.cam.unique()):
        cs = cap[cap.cam == c].sort_values("mono_ns")
        ps = pre[pre.cam == c].sort_values("mono_ns")
        n = min(len(cs), len(ps))
        if abs(len(cs) - len(ps)) > 25:
            fifo_ok = False
        cap_i = cs.cap_ns.values[:n]
        syn_i = ps.pts_ns.values[:n]
        pair[int(c)] = (cap_i, syn_i)
        for ci, pts in zip(cap_i, syn_i):
            true_cap[(int(c), int(pts))] = int(ci)
    r["fifo_match_ok"] = fifo_ok
    # per-camera capture -> mux-door latency (validates the FIFO match against summary.md)
    r["cap_to_mux_p50_ms"] = {}
    for c in sorted(cap.cam.unique()):
        cs = cap[cap.cam == c].sort_values("mono_ns")
        ps = pre[pre.cam == c].sort_values("mono_ns")
        n = min(len(cs), len(ps))
        lat = (ps.mono_ns.values[:n] - cs.cap_ns.values[:n]) / 1e6
        r["cap_to_mux_p50_ms"][int(c)] = round(float(np.percentile(lat, 50)), 1)

    bat_push = dict(zip(bat.batch_idx.values, bat.mono_ns.values))
    spreads, spreads_syn, stale = [], [], defaultdict(list)
    for bidx, g in bf_ss.groupby("batch_idx"):
        caps_t, syn_t = [], []
        for _, row in g.iterrows():
            tc = true_cap.get((int(row.source_id), int(row.buf_pts_ns)))
            if tc is not None:
                caps_t.append(tc)
                stale[int(row.source_id)].append((bat_push[bidx] - tc) / 1e6)
            syn_t.append(int(row.buf_pts_ns))
        if len(caps_t) >= 2:
            spreads.append((max(caps_t) - min(caps_t)) / 1e6)
        if len(syn_t) >= 2:
            spreads_syn.append((max(syn_t) - min(syn_t)) / 1e6)

    def qtiles(v):
        if not v:
            return None
        v = np.array(v)
        return {"p50": round(float(np.percentile(v, 50)), 1),
                "p90": round(float(np.percentile(v, 90)), 1),
                "p99": round(float(np.percentile(v, 99)), 1),
                "max": round(float(v.max()), 1), "n": len(v)}
    r["batch_spread_true_ms"] = qtiles(spreads)
    r["batch_spread_synthetic_ms"] = qtiles(spreads_syn)
    r["staleness_ms_per_cam"] = {c: qtiles(v) for c, v in sorted(stale.items())}

    # (5) nearest-frame spread on true capture stamps (RT-BEV fig5a definition)
    cam_caps = {int(c): np.sort(cap[(cap.cam == c) & (cap.mono_ns >= t0) & (cap.mono_ns <= t1)].cap_ns.values)
                for c in sorted(cap.cam.unique())}
    ref = cam_caps.get(0, np.array([]))
    nf = []
    for tref in ref:
        ts = [tref]
        ok = True
        for c, arr in cam_caps.items():
            if c == 0:
                continue
            if len(arr) == 0:
                ok = False; break
            i = np.searchsorted(arr, tref)
            best = min([j for j in (i - 1, i) if 0 <= j < len(arr)], key=lambda j: abs(int(arr[j]) - int(tref)))
            ts.append(arr[best])
        if ok:
            nf.append((max(ts) - min(ts)) / 1e6)
    r["nearest_frame_spread_ms"] = qtiles(nf)

    # persist CDF samples for figures (downsample to 400 quantile points)
    def cdf(v):
        if not v:
            return []
        v = np.sort(np.array(v))
        q = np.linspace(0, 1, 400)
        return np.quantile(v, q).round(2).tolist()
    r["cdf"] = {"nearest": cdf(nf), "batch_true": cdf(spreads), "batch_syn": cdf(spreads_syn),
                "stale": {c: cdf(v) for c, v in sorted(stale.items())}}

    # (6) raster sample: true capture instants + the synthetic PTS the same frames
    #     carry after jpegparse, for a 1.0 s window mid-run (the stagger figure)
    mid = (t0 + t1) // 2
    r["raster_true_ms"], r["raster_syn_s"] = {}, {}
    for c, (cap_i, syn_i) in pair.items():
        m = (cap_i >= mid) & (cap_i <= mid + int(1.0e9))
        r["raster_true_ms"][c] = ((cap_i[m] - mid) / 1e6).round(1).tolist()
        r["raster_syn_s"][c] = (syn_i[m] / 1e9).round(4).tolist()
    ft[run] = r

agg["frame_timing"] = ft
json.dump(agg, open(OUT, "w"), indent=1)
print("wrote", OUT)

# ---- console digest ----
for run, r in ft.items():
    print(f"\n== {run} ==  sync={r['meta']['sync_inputs']}")
    print(" anchor offsets vs cam0 (ms):", r["pts_anchor_offset_ms_vs_cam0"], "span", r["synthetic_offset_span_ms"])
    print(" first capture (s):", r["first_capture_s"])
    print(f" arrivals {r['arrivals_ss']}  out {r['frames_out_ss']}  discard {r['discard_pct']}%  "
          f"batches {r['batches_ss']}  full {r['pct_full_ss']}%  cadence {r['batch_cadence_median_ms']}ms")
    print(" survivors/cam:", r["survivors_per_cam_ss"], " sizes:", r["batch_size_hist_ss"])
    print(" top comps:", r["top_compositions_ss"][:4])
    print(" spread true:", r["batch_spread_true_ms"], "\n spread syn:", r["batch_spread_synthetic_ms"])
    print(" nearest-frame:", r["nearest_frame_spread_ms"])
    print(" staleness p50/cam:", {c: (v["p50"] if v else None) for c, v in r["staleness_ms_per_cam"].items()})

print("\n== sync_sweep ==")
for series, vals in agg["sync_sweep"].items():
    for ml, s in sorted(vals.items(), key=lambda kv: float(kv[0])):
        print(f" {series} ml={ml}: mean_nin={s.get('mean_nin')} pct_full={s.get('pct_full')} "
              f"batches={s.get('n_batches')} e2e={s.get('e2e_mean')} dist={s.get('dist')}")
print("\n== sync_grid ==")
for key, s in sorted(agg["sync_grid"].items(), key=lambda kv: (float(kv[0].split('_')[0]), float(kv[0].split('_')[1]))):
    print(f" ml_push={key}: mean_nin={s.get('mean_nin')} pct_full={s.get('pct_full')} "
          f"batches={s.get('n_batches')} batches_s={s.get('batches_s')} e2e={s.get('e2e_mean')}"
          + ("  DEAD" if s.get("dead") else ""))
