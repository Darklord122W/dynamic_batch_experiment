# Why the Batch Never Filled — Overleaf project

Technical report for `multicam_perception_rt`: why the `sync-inputs`
sweeps could never produce a full 4-camera batch, and the asymmetric
new-mux configuration that escapes the problem.

## Compile (Overleaf)

1. Overleaf → **New Project → Upload Project** → select this zip.
2. Compiler: **pdfLaTeX** (the default). No extra packages needed —
   everything used (`geometry`, `graphicx`, `booktabs`, `amsmath`,
   `caption`, `enumitem`, `placeins`, `hyperref`, `microtype`, `xcolor`)
   ships with Overleaf's TeX Live.
3. Main document: `main.tex`. Compile twice for the table of contents
   and cross-references to settle (Overleaf does this automatically).

## Contents

```
main.tex             the report (12 sections + 3 appendices)
figures/*.pdf        11 vector figures, generated from the repo's CSVs
tools/aggregate.py   recomputes every statistic from the raw CSVs -> agg.json
tools/figures.py     regenerates all 11 figures from agg.json
README.md            this file
```

## Figure inventory

| file | shows |
|---|---|
| fig_pipeline | the pipeline; where PTS is destroyed; where the pools are |
| fig_two_clocks | same 1 s of video on the real clock vs the synthetic PTS grids |
| fig_spread_cdf | cross-camera skew: physics (9 ms) vs as-batched (209 ms) vs synthetic (1050 ms) |
| fig_staleness | standing-queue skew: per-camera staleness 32–241 ms by startup order |
| fig_sync_off | control: with sync off the batch fills fine |
| fig_sweep_floor | all sync-on sweeps vs the measured 1.05–1.47 s requirement |
| fig_grid_heat | the 2-D sweep, incl. the frozen max-latency=500 ms row |
| fig_ceiling | requirement vs pool budget vs measured freeze boundary |
| fig_spiral | the pool-exhaustion death spiral |
| fig_sync_survivors | new mux @ 33 ms window: 93.6% erased; survivors = grid luck |
| fig_windows | EARLY/LATE gate anatomy: the workable config vs the 10 s trap |

## Regenerating the figures

The tools expect the `multicam_perception_rt` repository on disk (they read
`experiments/results/**` and `cpp/experiments/frame_timing/results/**`).
Edit the `ROOT` constant at the top of `tools/aggregate.py`, then:

```bash
python3 tools/aggregate.py     # -> agg.json next to the script
python3 tools/figures.py      # -> report/figures/*.{pdf,png}
```

Requires python3 with pandas, numpy, matplotlib (all present on the Jetson).

All numbers in the report were recomputed this way from the archived CSVs and
validated against the repository's own published statistics (Appendix B of
the report).
