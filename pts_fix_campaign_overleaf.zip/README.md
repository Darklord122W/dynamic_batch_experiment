# Fixing the Clock — Overleaf project

Campaign report for multicam_perception_rt (2026-07-07/08): the jpegparse
PTS-restore fix, the re-done baseline_pinned, the reproduced replay_skewed,
sync-inputs after the fix, and the engine x sync push-deadline sweeps.
Sequel to "Why the Batch Never Filled" (2026-07-06).

- Compile: pdfLaTeX (Overleaf default works as-is; no shell-escape needed).
- figures/ — PNGs exported from the analysis scripts at 110–150 dpi.
- tools/ — the scripts that regenerate every figure from the raw CSVs in the
  repository (cpp/experiments/frame_timing/results/* and
  experiments/results/timeout_sweep_cpp_*):
    analyze_timing.py       11 figures + summary.md per frame_timing run
    sync_replay_sweep.py    the sync window/timeout maps (fig_sync_replay_*)
    timeout_sweep_cpp.py    the sweep driver (timeout_sweep.png, detection_perf.png)
    replot_sweep.py         regenerate sweep figures from persisted CSV/JSONL

Source-of-truth MD docs: experiments/results/campaign_2026-07-07_ptsfix/ in
the repository (REPORT.md + STEP1..STEP5).
